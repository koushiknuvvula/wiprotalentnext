package com.wipro.flowcontrolstatements;

public class Exercise11 {
	public static void main(String[] args) {
		for(int index=24;index<=57;index=index+2)
		{
			System.out.println(index);
		}
	}

}
