package com.wipro.flowcontrolstatements;

public class Exercise4 {

	public static void main(String[] args) {
		char firstcharacter='b';
		char secondcharacter='a';
		if(firstcharacter<secondcharacter)
		{
			System.out.println(firstcharacter+","+secondcharacter);
		}
		else
		{
			System.out.println(secondcharacter+","+firstcharacter);	
		}
	}

}
