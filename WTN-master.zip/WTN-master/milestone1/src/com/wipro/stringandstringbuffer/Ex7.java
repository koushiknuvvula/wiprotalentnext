package com.wipro.stringandstringbuffer;

import java.util.Scanner;

public class Ex7 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String s1=s.next();
		if(s1.charAt(0)=='x')
		{
			
		}
	}

}
