package com.wipro.interfaces.music;

public interface Playable {
	public void play();

}
