package com.wipro.interfaces.music.wind;
import com.wipro.interfaces.music.*;

public class Saxophone implements Playable {
	@Override
	public void play()
	{
		System.out.println("Saxophone instrument is playing");
	}
	

}
