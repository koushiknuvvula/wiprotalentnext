package com.wipro.languagebasics;
public class Exercise3 {

	public static void main(String[] args) {
		int firstnumber;
		int secondnumber;
		int sumofnumbers;
		firstnumber=Integer.parseInt(args[0]);
		secondnumber=Integer.parseInt(args[1]);
		sumofnumbers=firstnumber+secondnumber;
		System.out.println("The sum of "+firstnumber+" and "+secondnumber+" is "+sumofnumbers);
		
	}

}
