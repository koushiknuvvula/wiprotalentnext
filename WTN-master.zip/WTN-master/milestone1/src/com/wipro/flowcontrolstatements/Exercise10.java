package com.wipro.flowcontrolstatements;

public class Exercise10 {

	public static void main(String[] args) {
	for(int index=1;index<=10;index++)
	{
		System.out.print(index+"\t");
	}
	
	}

}
