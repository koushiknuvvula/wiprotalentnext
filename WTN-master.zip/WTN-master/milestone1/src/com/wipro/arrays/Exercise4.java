package com.wipro.arrays;

public class Exercise4 {

	public static void main(String[] args) 
	{
			int []array=new int[] {65,67,100,98,70,77};
			int len=array.length;
			for(int i=0;i<len;i++)
			{
				System.out.print((char)(array[i]));
			}
	}

}
