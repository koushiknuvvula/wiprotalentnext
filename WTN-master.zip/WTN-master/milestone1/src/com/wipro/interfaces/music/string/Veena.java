package com.wipro.interfaces.music.string;
import com.wipro.interfaces.music.*;
public class Veena  implements Playable
{
	@Override
	public void play()
	{
		System.out.println("Veena instrument is playing");
	}

}
